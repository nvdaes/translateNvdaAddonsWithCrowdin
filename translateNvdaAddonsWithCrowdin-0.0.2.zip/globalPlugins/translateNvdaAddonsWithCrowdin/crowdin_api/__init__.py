from crowdin_api.client import CrowdinClient

__all__ = ["CrowdinClient"]
__author__ = "Crowdin"
__version__ = "1.21.0"

__pdoc__ = {
	"tests": False,
	"fixtures": False,
}
