from enum import Enum


class LanguageRecognitionProvider(Enum):
	CROWDIN = "crowdin"
	ENGINE = "engine"
