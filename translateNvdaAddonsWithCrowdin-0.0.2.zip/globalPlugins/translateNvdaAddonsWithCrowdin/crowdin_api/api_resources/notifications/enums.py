from enum import Enum


class MemberRole(Enum):
	OWNER = "owner"
	MANAGER = "manager"
